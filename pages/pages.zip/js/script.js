//Variables----------------------------------------------------------------

//Var - User
let userFirstName;
let userLastName;
let userEmail;
let userPhone;
let userCardNumber;
let userCardExpDate;
let userCardCVC;

//Var - Recipient
let deliveryFirstName;
let deliveryLastName;
let deliveryPhone;
let deliveryAddress;
let deliveryCity;
let deliveryPostCode;
let deliveryMessage;

//Var - Contact
let contactFirstName;
let contactLastName;
let contactEmail;
let contactMessage;

// //Functions----------------------------------------------------------------

// //Fun - Contact Form

let buttonSubmitContactForm = document.getElementById(
  "buttonSubmitContactForm"
);
let buttonCloseMessagePopup = document.getElementById(
  "buttonCloseMessagePopup"
);

function submitMessage() {
  let contactFirstName = document.getElementById("fName").value;
  let contactLastName = document.getElementById("lName").value;
  let contactEmail = document.getElementById("email").value;
  let contactMessage = document.getElementById("message").value;
  if (
    contactFirstName.length > 0 &&
    contactLastName.length > 0 &&
    contactEmail.length > 0 &&
    contactMessage.length > 0
  ) {
    document.getElementById("messageSent").style.display = "flex";
    document.getElementById(
      "messageSentH2"
    ).innerHTML = `Thank you, ${contactFirstName}!`;
  }
}

function closeMessagePopup() {
  document.getElementById("messageSent").style.display = "none";
}

//Fun - Submit order
let buttonSubmitOrder = document.getElementById("buttonSubmitOrder");
let buttonCloseOrderPopup = document.getElementById("buttonCloseOrderPopup");

function submitOrder() {
  let deliveryFirstName = document.getElementById("fName");
  let deliveryLastName = document.getElementById("lName");
  let deliveryPhone = document.getElementById("phone");
  let deliveryAddress = document.getElementById("address");
  let deliveryCity = document.getElementById("city");
  let deliveryPostCode = document.getElementById("postcode");
  let userFirstName = document.getElementById("userfName");
  let userLastName = document.getElementById("userlName");
  let userEmail = document.getElementById("userEmail");
  let userPhone = document.getElementById("userPhone");
  let userCardNumber = document.getElementById("card");
  let userCardExpDate = document.getElementById("expDate");
  let userCardCVC = document.getElementById("cvc");

  if (
    deliveryFirstName.length > 0 &&
    deliveryLastName.length > 0 &&
    deliveryPhone.length > 0 &&
    deliveryAddress.length > 0 &&
    deliveryCity.length > 0 &&
    deliveryPostCode.length > 0 &&
    userFirstName.length > 0 &&
    userLastName.length > 0 &&
    userEmail.length > 0 &&
    userPhone.length > 0 &&
    userCardNumber.length > 0 &&
    userCardExpDate.length > 0 &&
    userCardCVC.length > 0
  ) {
    document.getElementById("orderSent").style.display = "flex";
  }
}

function closeOrderPopup() {
  document.getElementById("messageSent").style.display = "none";
}
